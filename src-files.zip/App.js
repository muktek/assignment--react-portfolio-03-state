import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <div className="App" id="app-container">
        / Add Components Here in App - component  /
      </div>
    );
  }
}

export default App;
